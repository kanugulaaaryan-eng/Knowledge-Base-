import * as yaml from 'js-yaml';

export interface ParsedNote {
  frontmatter: Record<string, unknown>;
  content: string;
  tags: string[];
  title: string;
}

export const parseFrontmatter = (rawContent: string): ParsedNote => {
  const frontmatterRegex = /^---\n([\s\S]*?)\n---/;
  const match = rawContent.match(frontmatterRegex);

  let frontmatter: Record<string, unknown> = {};
  let content = rawContent;
  let tags: string[] = [];
  let title = '';

  if (match) {
    // Strip the --- delimiter block regardless of whether the YAML inside
    // parses successfully. Previously this only happened inside the try
    // block, so a malformed frontmatter block (invalid YAML) would leak the
    // raw "---\n...\n---" delimiters into the note's visible content.
    content = rawContent.slice(match[0].length).trimStart();
    try {
      frontmatter = (yaml.load(match[1]) as Record<string, unknown>) || {};
    } catch {
      frontmatter = {};
    }
  }

  if (frontmatter.tags) {
    if (Array.isArray(frontmatter.tags)) {
      tags = frontmatter.tags.filter((t): t is string => typeof t === 'string');
    } else if (typeof frontmatter.tags === 'string') {
      tags = frontmatter.tags.split(',').map((t) => t.trim()).filter(Boolean);
    }
  }

  if (frontmatter.title && typeof frontmatter.title === 'string') {
    title = frontmatter.title;
  }

  return { frontmatter, content, tags, title };
};

export const serializeNote = (
  title: string,
  content: string,
  frontmatter: Record<string, unknown> = {}
): string => {
  const fm = { ...frontmatter, title };
  return `---\n${yaml.dump(fm)}---\n\n${content}`;
};