export interface WikiLink {
  title: string;
  displayText?: string;
  startIndex: number;
  endIndex: number;
}

export const parseWikiLinks = (content: string): WikiLink[] => {
  const links: WikiLink[] = [];
  const regex = /\[\[([^\]]+)\]\]/g;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(content)) !== null) {
    const fullMatch = match[0];
    const inner = match[1];
    let title = inner;
    let displayText = inner;

    if (inner.includes('|')) {
      [title, displayText] = inner.split('|', 2);
    }

    links.push({
      title: title.trim(),
      displayText: displayText.trim(),
      startIndex: match.index,
      endIndex: match.index + fullMatch.length,
    });
  }

  return links;
};

export const extractLinkTitles = (content: string): string[] => {
  return parseWikiLinks(content).map((link) => link.title.toLowerCase());
};

// Escapes markdown-significant characters in link display text so that
// e.g. a display text containing "]" doesn't break the generated link syntax.
const escapeMarkdownText = (text: string): string => text.replace(/[\\[\]]/g, (ch) => `\\${ch}`);

// encodeURIComponent leaves "(" and ")" unescaped, which would otherwise
// break a markdown link's "(url)" part if a note title contains them.
const encodeWikiTarget = (title: string): string =>
  encodeURIComponent(title).replace(/[()]/g, (ch) => (ch === '(' ? '%28' : '%29'));

// Converts [[Title]] / [[Title|Display]] wiki-link syntax into a real
// markdown link using a custom "wikilink://" scheme. This is meant to be
// fed into ReactMarkdown, which will HTML-escape everything for us — unlike
// the old replaceWikiLinks, which built raw HTML strings for
// dangerouslySetInnerHTML and let unescaped note titles/content through
// (a stored-XSS bug). Resolving the scheme to an actual note and handling
// the click is done in a custom "a" component renderer (see Editor.tsx),
// which also fixes wiki-links not being clickable at all previously.
export const wikiLinksToMarkdown = (content: string): string => {
  return content.replace(/\[\[([^\]]+)\]\]/g, (_match, inner: string) => {
    let title = inner;
    let displayText = inner;

    if (inner.includes('|')) {
      [title, displayText] = inner.split('|', 2);
    }

    title = title.trim();
    displayText = displayText.trim();

    return `[${escapeMarkdownText(displayText)}](wikilink://${encodeWikiTarget(title)})`;
  });
};