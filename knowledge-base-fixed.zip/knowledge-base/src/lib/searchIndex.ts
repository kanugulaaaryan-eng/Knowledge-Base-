import MiniSearch from 'minisearch';
import { type Note } from '../db';

let miniSearch: MiniSearch<Note> | null = null;

export const buildSearchIndex = (notes: Note[]): MiniSearch<Note> => {
  const index = new MiniSearch({
    fields: ['title', 'content', 'tags'],
    storeFields: ['title', 'id', 'tags'],
    searchOptions: {
      boost: { title: 2 },
      fuzzy: 0.2,
      prefix: true,
    },
  });

  index.addAll(notes);
  miniSearch = index;
  return index;
};

export const getSearchIndex = (): MiniSearch<Note> | null => {
  return miniSearch;
};

export const searchNotes = (query: string): { id: string; title: string; tags: string[] }[] => {
  if (!miniSearch || !query.trim()) return [];
  const results = miniSearch.search(query.trim());
  return results.map((r) => ({
    id: r.id,
    title: r.title,
    tags: r.tags || [],
  }));
};