import { useState, useEffect, useRef, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { updateNote, createNote, type Note } from '../db';
import { parseWikiLinks, wikiLinksToMarkdown } from '../lib/linkParser';
import { serializeNote } from '../lib/frontmatter';

interface EditorProps {
  noteId: string | null;
  note: Note | null;
  notes: Note[];
  onSave: () => void;
  onNavigate: (id: string) => void;
}

export default function Editor({ noteId, note, notes, onSave, onNavigate }: EditorProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [frontmatter, setFrontmatter] = useState<Record<string, unknown>>({});
  const [showFrontmatter, setShowFrontmatter] = useState(false);
  const [saving, setSaving] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const processedContent = useMemo(() => wikiLinksToMarkdown(content), [content]);

  // Resolves "wikilink://" links produced by wikiLinksToMarkdown to a real
  // note and handles the click via onNavigate, instead of the previous
  // approach (raw HTML anchors with an href nothing ever listened for).
  const markdownComponents = useMemo(
    () => ({
      a: ({ href, children }: { href?: string; children?: React.ReactNode }) => {
        if (href?.startsWith('wikilink://')) {
          const linkTitle = decodeURIComponent(href.slice('wikilink://'.length));
          const target = notes.find((n) => n.title.toLowerCase() === linkTitle.toLowerCase());

          if (target) {
            return (
              <a
                href={`#note/${target.id}`}
                className="wiki-link"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate(target.id);
                }}
              >
                {children}
              </a>
            );
          }
          return (
            <span className="wiki-link missing" title={`Note "${linkTitle}" not found`}>
              {children}
            </span>
          );
        }
        return (
          <a href={href} target="_blank" rel="noopener noreferrer">
            {children}
          </a>
        );
      },
    }),
    [notes, onNavigate]
  );

  // Previously this re-fetched the note from IndexedDB even though `note`
  // (passed in from App's already-loaded `notes` state) has everything we
  // need. That extra async round trip had no benefit and was also racy:
  // switching notes quickly could let an older fetch resolve after a newer
  // one and stomp the newer note's fields with stale data. Using the prop
  // directly is both simpler and correct.
  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setFrontmatter(note.frontmatter || {});
    } else {
      setTitle('');
      setContent('');
      setFrontmatter({});
    }
  }, [noteId, note]);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);

    const rawContent = serializeNote(title, content, frontmatter);

    if (noteId) {
      await updateNote(noteId, { title, content, rawContent });
    } else {
      await createNote({ title, content, rawContent, tags: [], frontmatter: {} });
    }

    setSaving(false);
    onSave();
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleFrontmatterChange = (key: string, value: unknown) => {
    setFrontmatter((prev) => ({ ...prev, [key]: value }));
  };

  const handleFrontmatterKeyChange = (oldKey: string, newKey: string) => {
    setFrontmatter((prev) => {
      const next = { ...prev };
      const value = next[oldKey];
      delete next[oldKey];
      if (newKey.trim()) next[newKey.trim()] = value;
      return next;
    });
  };

  const handleFrontmatterDelete = (key: string) => {
    setFrontmatter((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const addFrontmatterField = () => {
    setFrontmatter((prev) => ({ ...prev, 'new-field': '' }));
  };

  // This must run before the early return below — a hook called only on
  // some render paths (e.g. skipped when no note is selected, called once
  // one is) violates React's Rules of Hooks and breaks hook state when
  // toggling between an empty editor and a populated one.
  const backlinks = useMemo(() => {
    if (!noteId) return [];
    const targetNote = notes.find((n) => n.id === noteId);
    if (!targetNote) return [];

    return notes
      .filter((n) => n.id !== noteId)
      .filter((n) => {
        const links = parseWikiLinks(n.content);
        return links.some((l) => l.title.toLowerCase() === targetNote.title.toLowerCase());
      });
  }, [noteId, notes]);

  if (!noteId && !note) {
    return (
      <div className="editor empty">
        <p>Select a note or create a new one</p>
      </div>
    );
  }

  return (
    <div className="editor">
      <div className="editor-header">
        <input
          type="text"
          value={title}
          onChange={handleTitleChange}
          placeholder="Note title"
          className="title-input"
        />
        <button
          type="button"
          className="frontmatter-toggle"
          onClick={() => setShowFrontmatter(!showFrontmatter)}
        >
          {showFrontmatter ? 'Hide Frontmatter' : 'Show Frontmatter'}
        </button>
        <button className="save-btn" onClick={handleSave} disabled={saving}>
          {saving ? 'Saving...' : 'Save'}
        </button>
      </div>

      {showFrontmatter && (
        <div className="frontmatter-editor">
          <h4>Frontmatter</h4>
          {Object.entries(frontmatter).map(([key, value]) => (
            <div key={key} className="frontmatter-field">
              <input
                type="text"
                value={key}
                onChange={(e) => handleFrontmatterKeyChange(key, e.target.value)}
                className="fm-key"
                placeholder="key"
              />
              <input
                type="text"
                value={String(value)}
                onChange={(e) => handleFrontmatterChange(key, e.target.value)}
                className="fm-value"
                placeholder="value"
              />
              <button
                type="button"
                className="fm-delete"
                onClick={() => handleFrontmatterDelete(key)}
                aria-label="Delete field"
              >
                ×
              </button>
            </div>
          ))}
          <button type="button" className="add-fm-field" onClick={addFrontmatterField}>
            + Add Field
          </button>
        </div>
      )}

      <div className="editor-split">
        <div className="editor-pane">
          <label>Edit</label>
          <textarea
            ref={textareaRef}
            value={content}
            onChange={handleContentChange}
            className="editor-textarea"
            spellCheck={false}
            placeholder="Start writing... Use [[Wiki Links]] to connect notes."
          />
        </div>

        <div className="editor-pane preview-pane">
          <label>Preview</label>
          <div className="preview-content">
            <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
              {processedContent}
            </ReactMarkdown>
          </div>
        </div>
      </div>

      <div className="backlinks">
        <h4>Backlinks</h4>
        {backlinks.length === 0 ? (
          <p className="no-backlinks">No backlinks yet</p>
        ) : (
          <ul className="backlinks-list">
            {backlinks.map((note) => (
              <li key={note.id}>
                <button className="backlink-item" onClick={() => onNavigate(note.id)}>
                  {note.title}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}