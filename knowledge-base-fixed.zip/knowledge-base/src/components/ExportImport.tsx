import { useState, useRef } from 'react';
import { db } from '../db';
import { type Note } from '../db';

interface ExportImportProps {
  notes: Note[];
  onImport: () => void;
}

export default function ExportImport({ notes, onImport }: ExportImportProps) {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importMessage, setImportMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleExport = () => {
    setExporting(true);
    try {
      const data = {
        version: 1,
        exportedAt: new Date().toISOString(),
        notes: notes.map((n) => ({
          id: n.id,
          title: n.title,
          content: n.content,
          rawContent: n.rawContent,
          tags: n.tags,
          frontmatter: n.frontmatter,
          createdAt: n.createdAt,
          updatedAt: n.updatedAt,
        })),
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `knowledge-base-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setExporting(false);
    }
  };

  const handleImport = async (file: File) => {
    setImporting(true);
    setImportMessage(null);
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (!data.notes || !Array.isArray(data.notes)) {
        throw new Error('Invalid backup format');
      }

      let imported = 0;
      for (const note of data.notes) {
        // Previously only id/title were checked, so a backup with e.g.
        // tags as a string instead of an array, or missing content, would
        // still get written to the DB — and then crash the app later
        // wherever code assumes these fields exist with the right shape
        // (note.content.toLowerCase(), note.tags.some(...), etc).
        if (
          !note ||
          typeof note.id !== 'string' ||
          typeof note.title !== 'string' ||
          typeof note.content !== 'string' ||
          typeof note.rawContent !== 'string' ||
          !Array.isArray(note.tags) ||
          typeof note.createdAt !== 'number' ||
          typeof note.updatedAt !== 'number'
        ) {
          continue;
        }

        const safeNote = { ...note, frontmatter: note.frontmatter ?? {} };
        const existing = await db.notes.get(safeNote.id);
        if (!existing || safeNote.updatedAt > existing.updatedAt) {
          await db.notes.put(safeNote);
          imported++;
        }
      }

      setImportMessage({ type: 'success', text: `Imported ${imported} note${imported !== 1 ? 's' : ''}` });
      onImport();
    } catch (err) {
      setImportMessage({ type: 'error', text: `Import failed: ${err instanceof Error ? err.message : 'Unknown error'}` });
    } finally {
      setImporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleImport(file);
    e.target.value = '';
  };

  return (
    <div className="export-import">
      <div className="export-section">
        <h4>Export Data</h4>
        <p className="section-desc">Download all notes as a JSON backup file</p>
        <button className="export-btn" onClick={handleExport} disabled={exporting}>
          {exporting ? 'Exporting...' : 'Export JSON'}
        </button>
      </div>

      <div className="import-section">
        <h4>Import Data</h4>
        <p className="section-desc">Restore notes from a JSON backup file</p>
        <button className="import-btn" onClick={() => fileInputRef.current?.click()} disabled={importing}>
          {importing ? 'Importing...' : 'Choose File'}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleFileSelect}
          className="hidden-file-input"
          disabled={importing}
        />
      </div>

      {importMessage && (
        <div className={`import-message ${importMessage.type}`}>
          {importMessage.text}
        </div>
      )}
    </div>
  );
}