import { type Note } from '../db';

interface NoteListProps {
  notes: Note[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
}

export default function NoteList({ notes, selectedId, onSelect, onNew }: NoteListProps) {
  return (
    <div className="note-list">
      <button className="new-note-btn" onClick={onNew}>
        + New Note
      </button>
      <ul>
        {notes.map((note) => (
          <li key={note.id}>
            <button
              className={`note-item ${note.id === selectedId ? 'selected' : ''}`}
              onClick={() => onSelect(note.id)}
            >
              <span className="note-title">{note.title || 'Untitled'}</span>
              {note.tags.length > 0 && (
                <span className="note-tags">
                  {note.tags.map((tag) => (
                    <span key={tag} className="tag">#{tag}</span>
                  ))}
                </span>
              )}
            </button>
          </li>
        ))}
        {notes.length === 0 && (
          <li className="empty-state">No notes yet. Click + to create one.</li>
        )}
      </ul>
    </div>
  );
}