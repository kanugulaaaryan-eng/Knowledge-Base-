import { useEffect, useRef, useMemo } from 'react';
import cytoscape from 'cytoscape';
import { parseWikiLinks } from '../lib/linkParser';
import { type Note } from '../db';

interface GraphViewProps {
  notes: Note[];
  onNodeClick: (id: string) => void;
}

export default function GraphView({ notes, onNodeClick }: GraphViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);

  const elements = useMemo(() => {
    const nodes = notes.map((note) => ({
      data: { id: note.id, label: note.title },
      classes: 'note-node',
    }));

    const edges: Array<{ data: { id: string; source: string; target: string } }> = [];
    const noteByTitle = new Map(notes.map((n) => [n.title.toLowerCase(), n.id]));

    notes.forEach((note) => {
      const links = parseWikiLinks(note.content);
      links.forEach((link) => {
        const targetId = noteByTitle.get(link.title.toLowerCase());
        if (targetId && targetId !== note.id) {
          edges.push({
            data: {
              id: `${note.id}-${targetId}`,
              source: note.id,
              target: targetId,
            },
          });
        }
      });
    });

    return [...nodes, ...edges];
  }, [notes]);

  useEffect(() => {
    if (!containerRef.current) return;

    if (cyRef.current) {
      cyRef.current.destroy();
    }

    const cy = cytoscape({
      container: containerRef.current,
      elements,
      style: [
        {
          selector: 'node',
          style: {
            label: 'data(label)',
            'font-size': '12px',
            'text-valign': 'bottom',
            'text-halign': 'center',
            'background-color': '#3b8bff',
            color: '#fff',
            'text-outline-color': '#3b8bff',
            'text-outline-width': 2,
            width: 'label',
            height: 'label',
            padding: '10px',
            'min-width': '60px',
            'min-height': '30px',
          },
        },
        {
          selector: 'edge',
          style: {
            width: 2,
            'line-color': '#666',
            'target-arrow-shape': 'triangle',
            'target-arrow-color': '#666',
            'curve-style': 'bezier',
          },
        },
      ],
      layout: { name: 'cose', animate: true, fit: true },
    });

    cyRef.current = cy;

    cy.on('tap', 'node', (event) => {
      const nodeId = event.target.id();
      onNodeClick(nodeId);
    });

    return () => {
      cy.destroy();
      cyRef.current = null;
    };
  }, [elements, onNodeClick]);

  return (
    <div className="graph-view">
      <div className="graph-header">
        <h3>Knowledge Graph</h3>
        <p className="graph-hint">Click a node to open the note</p>
      </div>
      <div ref={containerRef} style={{ width: '100%', height: '100%', minHeight: '400px' }} />
    </div>
  );
}