import { useMemo } from 'react';
import { type Note } from '../db';

interface TagsViewProps {
  notes: Note[];
  selectedTag: string | null;
  onTagSelect: (tag: string | null) => void;
  onNoteSelect: (id: string) => void;
}

export default function TagsView({ notes, selectedTag, onTagSelect, onNoteSelect }: TagsViewProps) {
  const allTags = useMemo(() => {
    const tagCounts = new Map<string, number>();
    notes.forEach((note) => {
      note.tags.forEach((tag) => {
        tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
      });
    });
    return Array.from(tagCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([tag, count]) => ({ tag, count }));
  }, [notes]);

  const filteredNotes = useMemo(() => {
    if (!selectedTag) return notes;
    return notes.filter((note) => note.tags.includes(selectedTag));
  }, [notes, selectedTag]);

  return (
    <div className="tags-view">
      <div className="tags-sidebar">
        <h4>All Tags</h4>
        <button
          className={`tag-item ${!selectedTag ? 'selected' : ''}`}
          onClick={() => onTagSelect(null)}
        >
          <span>All Notes</span>
          <span className="tag-count">{notes.length}</span>
        </button>
        {allTags.map(({ tag, count }) => (
          <button
            key={tag}
            className={`tag-item ${selectedTag === tag ? 'selected' : ''}`}
            onClick={() => onTagSelect(tag)}
          >
            <span>#{tag}</span>
            <span className="tag-count">{count}</span>
          </button>
        ))}
        {allTags.length === 0 && (
          <p className="no-tags">No tags yet. Add tags in frontmatter.</p>
        )}
      </div>

      <div className="tags-notes">
        <div className="tags-notes-header">
          <h4>{selectedTag ? `Tag: #${selectedTag}` : 'All Notes'}</h4>
          <span className="note-count">{filteredNotes.length} note{filteredNotes.length !== 1 ? 's' : ''}</span>
        </div>
        <ul className="tags-note-list">
          {filteredNotes.map((note) => (
            <li key={note.id}>
              <button
                className="tag-note-item"
                onClick={() => onNoteSelect(note.id)}
              >
                <span className="tag-note-title">{note.title || 'Untitled'}</span>
                {note.tags.length > 0 && (
                  <span className="tag-note-tags">
                    {note.tags.map((tag) => (
                      <span key={tag} className="tag">{tag}</span>
                    ))}
                  </span>
                )}
              </button>
            </li>
          ))}
          {filteredNotes.length === 0 && (
            <li className="empty-state">No notes{selectedTag ? ` with tag #${selectedTag}` : ''}</li>
          )}
        </ul>
      </div>
    </div>
  );
}