import { useState, useRef, useEffect } from 'react';

interface SearchBarProps {
  query: string;
  onChange: (query: string) => void;
  results: Array<{ id: string; title: string; tags: string[] }>;
  onSelect: (id: string) => void;
}

export default function SearchBar({ query, onChange, results, onSelect }: SearchBarProps) {
  const [showResults, setShowResults] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
    setShowResults(true);
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((i) => Math.min(i + 1, results.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((i) => Math.max(i - 1, -1));
    } else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      onSelect(results[selectedIndex].id);
      setShowResults(false);
    } else if (e.key === 'Escape') {
      setShowResults(false);
      inputRef.current?.blur();
    }
  };

  const handleResultClick = (id: string) => {
    onSelect(id);
    setShowResults(false);
  };

  const handleBlur = () => {
    setTimeout(() => setShowResults(false), 200);
  };

  return (
    <div className="search-bar">
      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onFocus={() => setShowResults(true)}
        onBlur={handleBlur}
        placeholder="Search notes... (Ctrl+K)"
        className="search-input"
        autoComplete="off"
      />
      {showResults && results.length > 0 && (
        <ul className="search-results">
          {results.map((result, index) => (
            <li
              key={result.id}
              className={`search-result ${index === selectedIndex ? 'selected' : ''}`}
              onClick={() => handleResultClick(result.id)}
            >
              <span className="result-title">{result.title}</span>
              {result.tags.length > 0 && (
                <span className="result-tags">
                  {result.tags.map((tag) => (
                    <span key={tag} className="tag">#{tag}</span>
                  ))}
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
      {showResults && results.length === 0 && query.trim() && (
        <div className="search-empty">No results for "{query}"</div>
      )}
    </div>
  );
}