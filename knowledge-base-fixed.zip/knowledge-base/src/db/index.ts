import Dexie, { type Table } from 'dexie';
import { parseFrontmatter, serializeNote } from '../lib/frontmatter';

export interface Note {
  id: string;
  title: string;
  content: string;
  rawContent: string;
  tags: string[];
  frontmatter: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

export class KnowledgeBaseDB extends Dexie {
  notes!: Table<Note, string>;

  constructor() {
    super('knowledge-base');
    this.version(1).stores({
      notes: 'id, title, tags, createdAt, updatedAt',
    });
    // v1's `tags` index was not multi-entry, so it indexed each note's whole
    // tags array as a single key. getNotesByTag's `.where('tags').equals(tag)`
    // compared that array against a plain string and could never match.
    // `*tags` tells Dexie to index each array element individually.
    this.version(2).stores({
      notes: 'id, title, *tags, createdAt, updatedAt',
    });
  }
}

export const db = new KnowledgeBaseDB();

const processNoteContent = (title: string, content: string, frontmatter?: Record<string, unknown>) => {
  const rawContent = frontmatter ? serializeNote(title, content, frontmatter) : content;
  const parsed = parseFrontmatter(rawContent);
  return {
    title: parsed.title || title,
    content: parsed.content,
    rawContent,
    tags: parsed.tags,
    frontmatter: parsed.frontmatter,
  };
};

export const createNote = async (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt' | 'rawContent'> & { id?: string; rawContent?: string }) => {
  const now = Date.now();
  const id = note.id || crypto.randomUUID();
  
  const processed = note.rawContent 
    ? { ...parseFrontmatter(note.rawContent), rawContent: note.rawContent }
    : processNoteContent(note.title, note.content, note.frontmatter);
  
  const newNote: Note = {
    ...note,
    id,
    ...processed,
    createdAt: now,
    updatedAt: now,
  };
  await db.notes.put(newNote);
  return newNote;
};

export const getNote = async (id: string) => {
  return db.notes.get(id);
};

export const updateNote = async (id: string, updates: Partial<Note>) => {
  const note = await db.notes.get(id);
  if (!note) return null;
  
  const processed = updates.rawContent
    ? { ...parseFrontmatter(updates.rawContent), rawContent: updates.rawContent }
    : processNoteContent(
        updates.title ?? note.title,
        updates.content ?? note.content,
        updates.frontmatter ?? note.frontmatter
      );
  
  const updated: Note = {
    ...note,
    ...updates,
    ...processed,
    updatedAt: Date.now(),
  };
  await db.notes.put(updated);
  return updated;
};

export const deleteNote = async (id: string) => {
  await db.notes.delete(id);
};

export const listNotes = async () => {
  return db.notes.orderBy('updatedAt').reverse().toArray();
};

export const getNotesByTag = async (tag: string) => {
  return db.notes.where('tags').equals(tag).toArray();
};

export const initializeSampleNotes = async () => {
  const count = await db.notes.count();
  if (count > 0) return;

  await createNote({
    title: 'Welcome',
    content: '# Welcome to Your Knowledge Base\n\nStart writing notes with **Markdown**. Link notes using `[[Wiki Links]]`.\n\nTry creating a new note: `[[Getting Started]]`',
    tags: ['welcome'],
    frontmatter: {},
  });

  await createNote({
    title: 'Getting Started',
    content: '# Getting Started\n\n- Create notes with the **+** button\n- Use `[[Note Title]]` to link notes\n- View connections in the **Graph** tab\n- Search with **Ctrl+K**',
    tags: ['guide', 'welcome'],
    frontmatter: {},
  });

  await createNote({
    title: 'Markdown Guide',
    content: '# Markdown Guide\n\n## Headers\n# H1\n## H2\n### H3\n\n## Lists\n- Item 1\n- Item 2\n  - Nested\n\n## Code\n```js\nconsole.log("hello");\n```\n\n## Links\n[[Wiki Links]] connect notes.\n[External links](https://example.com) work too.',
    tags: ['guide', 'markdown'],
    frontmatter: {},
  });
};