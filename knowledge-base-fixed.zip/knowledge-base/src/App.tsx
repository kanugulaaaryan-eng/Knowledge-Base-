import { useState, useEffect } from 'react';
import { type Note } from './db';
import { initializeSampleNotes, listNotes } from './db';
import { buildSearchIndex, searchNotes } from './lib/searchIndex';
import NoteList from './components/NoteList';
import Editor from './components/Editor';
import GraphView from './components/GraphView';
import SearchBar from './components/SearchBar';
import TagsView from './components/TagsView';
import ExportImport from './components/ExportImport';
import './App.css';

function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [view, setView] = useState<'editor' | 'graph' | 'tags' | 'settings'>('editor');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Array<{ id: string; title: string; tags: string[] }>>([]);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  useEffect(() => {
    initializeSampleNotes().then(() => {
      listNotes().then((loadedNotes) => {
        setNotes(loadedNotes);
        buildSearchIndex(loadedNotes);
      });
    });
  }, []);

  const handleNoteChange = async () => {
    const updated = await listNotes();
    setNotes(updated);
    buildSearchIndex(updated);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      const results = searchNotes(query);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleSearchSelect = (id: string) => {
    setSelectedNoteId(id);
    setSearchQuery('');
    setSearchResults([]);
    setView('editor');
  };

  // GraphView, TagsView, and Editor's backlinks/wiki-links all need to jump
  // to a note. Previously they only called setSelectedNoteId, which updated
  // state invisibly because the main panel only renders <Editor> when
  // view === 'editor' — so clicking a graph node or a tagged note did
  // nothing visible. This handler does both.
  const handleNavigateToNote = (id: string) => {
    setSelectedNoteId(id);
    setView('editor');
  };

  const handleNewNote = async () => {
    const { createNote } = await import('./db');
    const newNote = await createNote({
      title: 'Untitled',
      content: '',
      tags: [],
      frontmatter: {},
    });
    const updated = await listNotes();
    setNotes(updated);
    buildSearchIndex(updated);
    setSelectedNoteId(newNote.id);
  };

  const handleImportComplete = async () => {
    const updated = await listNotes();
    setNotes(updated);
    buildSearchIndex(updated);
  };

  const currentNote = notes.find((n) => n.id === selectedNoteId);

  return (
    <div className="app">
      <header className="header">
        <h1>Knowledge Base</h1>
        <SearchBar
          query={searchQuery}
          onChange={handleSearch}
          results={searchResults}
          onSelect={handleSearchSelect}
        />
      </header>

      <div className="layout">
        <aside className="sidebar">
          <nav className="tabs">
            <button
              className={view === 'editor' ? 'active' : ''}
              onClick={() => setView('editor')}
            >
              Notes
            </button>
            <button
              className={view === 'graph' ? 'active' : ''}
              onClick={() => setView('graph')}
            >
              Graph
            </button>
            <button
              className={view === 'tags' ? 'active' : ''}
              onClick={() => setView('tags')}
            >
              Tags
            </button>
            <button
              className={view === 'settings' ? 'active' : ''}
              onClick={() => setView('settings')}
            >
              Settings
            </button>
          </nav>

          {view === 'editor' && (
            <NoteList
              notes={notes}
              selectedId={selectedNoteId}
              onSelect={setSelectedNoteId}
              onNew={handleNewNote}
            />
          )}

          {view === 'graph' && <GraphView notes={notes} onNodeClick={handleNavigateToNote} />}

          {view === 'tags' && (
            <TagsView
              notes={notes}
              selectedTag={selectedTag}
              onTagSelect={setSelectedTag}
              onNoteSelect={handleNavigateToNote}
            />
          )}

          {view === 'settings' && <ExportImport notes={notes} onImport={handleImportComplete} />}
        </aside>

        <main className="main">
          {view === 'editor' && (
            <Editor
              noteId={selectedNoteId}
              note={currentNote || null}
              notes={notes}
              onSave={handleNoteChange}
              onNavigate={handleNavigateToNote}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;